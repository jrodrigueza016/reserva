﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace app.Clases
{
    class usuario : conexion
    {

        public usuario() { 
            
        }

        public usuario(string identificador,string nombre,string p_apellido,string s_apellido,string correo,string telefono,string rol) {

            this.identificador = identificador;
            this.nombre = nombre;
            this.p_apellido = p_apellido;
            this.s_apellido = s_apellido;
            this.correo = correo;
            this.telefono = telefono;
            this.rol = rol;

        }


        private string identificador;  // the name field
        public string Identificador    // the identificador property
        {
            get
            {
                return identificador;
            }
            set
            {
                identificador = value;
            }
        }


        private string nombre;  // the name field
        public string Nombre    // the identificador property
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }

        private string p_apellido;  // the name field
        public string P_apellido    // the identificador property
        {
            get
            {
                return p_apellido;
            }
            set
            {
                p_apellido = value;
            }
        }

        private string s_apellido;  // the name field
        public string S_apellido    // the identificador property
        {
            get
            {
                return s_apellido;
            }
            set
            {
                s_apellido = value;
            }
        }


        private string telefono;  // the name field
        public string Telefono    // the identificador property
        {
            get
            {
                return telefono;
            }
            set
            {
                telefono = value;
            }
        }

        private string correo;  // the name field
        public string Correo    // the identificador property
        {
            get
            {
                return correo;
            }
            set
            {
                correo = value;
            }
        }

        private string rol;  // the name field
        public string Rol    // the identificador property
        {
            get
            {
                return rol;
            }
            set
            {
                rol = value;
            }
        }

        public int ingresar_usuario() {

            string sql = "";
            int resultado = 0;
            sql = "INSERT INTO usuario (identificador,nombre,p_apellido,s_apellido,telefono,correo,rol) VALUES (@identificador,@nombre,@p_apellido,@s_apellido,@telefono,@correo,@rol)";
            OleDbCommand cmd = new OleDbCommand(sql,this.conn);

            OleDbParameter identificador = new OleDbParameter();
            identificador.ParameterName = "identificador";
            identificador.OleDbType = OleDbType.VarChar;
            identificador.Value = this.identificador;

            OleDbParameter nombre = new OleDbParameter();
            nombre.ParameterName = "nombre";
            nombre.OleDbType = OleDbType.VarChar;
            nombre.Value = this.nombre;

            OleDbParameter p_apellido = new OleDbParameter();
            p_apellido.ParameterName = "p_apellido";
            p_apellido.OleDbType = OleDbType.VarChar;
            p_apellido.Value = this.p_apellido;

            OleDbParameter s_apellido = new OleDbParameter();
            s_apellido.ParameterName = "s_apellido";
            s_apellido.OleDbType = OleDbType.VarChar;
            s_apellido.Value = this.s_apellido;

            OleDbParameter telefono = new OleDbParameter();
            telefono.ParameterName = "telefono";
            telefono.OleDbType = OleDbType.VarChar;
            telefono.Value = this.telefono;

            OleDbParameter correo = new OleDbParameter();
            correo.ParameterName = "correo";
            correo.OleDbType = OleDbType.VarChar;
            correo.Value = this.correo;

            OleDbParameter rol = new OleDbParameter();
            rol.ParameterName = "rol";
            rol.OleDbType = OleDbType.VarChar;
            rol.Value = this.rol;
          

            cmd.Parameters.Add(identificador);
            cmd.Parameters.Add(nombre);
            cmd.Parameters.Add(p_apellido);
            cmd.Parameters.Add(s_apellido);
            cmd.Parameters.Add(telefono);
            cmd.Parameters.Add(correo);
            cmd.Parameters.Add(rol);

            this.abrir_conexion();

            resultado = cmd.ExecuteNonQuery();

            this.cerrar_conexion();

            return resultado;
        
        }

        
    }
}
