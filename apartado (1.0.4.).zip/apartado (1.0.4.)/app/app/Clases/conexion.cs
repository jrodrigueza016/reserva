﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;

namespace app.Clases
{
    class conexion
    {
        public string message;
        protected System.Data.OleDb.OleDbConnection conn = new System.Data.OleDb.OleDbConnection();

        public conexion()
        {
            // TODO: Modify the connection string and include any
            // additional required properties for your database.
            //this.conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\jrodriguez\Documents\apartado\apartado (1.0.3)\app\app\db\apartados.accdb;
            //                               Persist Security Info=False;";

            this.conn.ConnectionString = item.dbcon;
       
        }

        public int cerrar_conexion()
        {
            int resutlado = 0;

            try
            {
                this.conn.Close();

                resutlado = 1;

                // Insert code to process data.
            }
            catch (Exception ex)
            {
                this.message = ex.ToString();
                resutlado = 0;
            }
            finally
            {
                /*this.conn.Close();

                if (message == "")
                {
                    message = "Ok";
                }*/

                this.message = "Ok";
            }

            return resutlado;

        }

        public int abrir_conexion()
        {
            int resutlado = 0;

            try
            {
                this.conn.Open();

                resutlado = 1;

                // Insert code to process data.
            }
            catch (Exception ex)
            {
                this.message = ex.ToString();
                resutlado = 0;
            }
            finally
            {
                /*this.conn.Close();

                if (message == "")
                {
                    message = "Ok";
                }*/

                this.message = "Ok";
            }

            return resutlado;

        }

        public DataSet datos(string query)
        {

                // Create an instance of SqlDataAdapter. Spcify the command and the connection
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, this.conn);
                // Create an instance of DataSet, which is an in-memory datastore for storing tables
                DataSet oDataSet = new DataSet();
                // Call the Fill() methods, which automatically opens the connection, executes the command 
                // and fills the dataset with data, and finally closes the connection.
                dataAdapter.Fill(oDataSet,"tabla_generica");

                return oDataSet;

        }

        public DataSet obtener_datos(string nombre_tabla)
        {

            DataSet oDataSet = this.datos("SELECT * FROM " + nombre_tabla);

            return oDataSet;

        }

    }
}
