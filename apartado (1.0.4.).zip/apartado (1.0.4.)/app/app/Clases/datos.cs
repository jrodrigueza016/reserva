﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Net;
using System.Data;
using System.Data.OleDb;



namespace app.Clases
{
    class datos : conexion
    {

        public usuario obtener_usuario_id(string identificador)
        {

            System.Data.DataSet datos_usuarios = new System.Data.DataSet();
            usuario Usuario = new usuario();
            datos_usuarios = this.datos("SELECT [identificador],[nombre],[p_apellido],[s_apellido],[telefono],[correo],[rol] FROM usuario WHERE identificador = '" + identificador + "'");

            try
            {
               
                Usuario.Identificador = datos_usuarios.Tables[0].Rows[0][0].ToString();
                Usuario.Nombre = datos_usuarios.Tables[0].Rows[0][1].ToString();
                Usuario.P_apellido = datos_usuarios.Tables[0].Rows[0][2].ToString();
                Usuario.S_apellido = datos_usuarios.Tables[0].Rows[0][3].ToString();
                Usuario.Telefono = datos_usuarios.Tables[0].Rows[0][4].ToString();
                Usuario.Correo = datos_usuarios.Tables[0].Rows[0][5].ToString();
                Usuario.Rol = datos_usuarios.Tables[0].Rows[0][6].ToString();
                return Usuario;
                 
            }
            catch (Exception e)
            {
                
            }
            finally 
            {
                this.conn.Close();
                Usuario = null;
                datos_usuarios = null;
            }

            return Usuario; 

        }

        public equipo obtener_equipo_id(string codigo)
        {
            System.Data.DataSet datos_usuarios = new System.Data.DataSet();
            equipo Usuario = new equipo();
            datos_usuarios = this.datos("SELECT [codigo],[tipo],[marca],[descripcion] FROM equipo WHERE codigo = '" + codigo + "'");

            Usuario.Codigo = datos_usuarios.Tables[0].Rows[0][0].ToString();
            Usuario.Tipo = datos_usuarios.Tables[0].Rows[0][1].ToString();
            Usuario.Marca = datos_usuarios.Tables[0].Rows[0][2].ToString();
            Usuario.Descripcion = datos_usuarios.Tables[0].Rows[0][3].ToString();

            this.conn.Close();

            return Usuario;

        }


        public apartado obtener_apartado_id(int id)
        {
            System.Data.DataSet datos_usuarios = new System.Data.DataSet();
            apartado apartado = new apartado();
            datos_usuarios = this.datos("SELECT [id_apartado],[identificador],[fecha],[turno],[descripcion] FROM apartado WHERE id_apartado = " + id);

            apartado.Id_apartado = (int)datos_usuarios.Tables[0].Rows[0][0];
            apartado.Identificador = datos_usuarios.Tables[0].Rows[0][1].ToString();
            apartado.Fecha = (DateTime)datos_usuarios.Tables[0].Rows[0][2];
            apartado.Turno = datos_usuarios.Tables[0].Rows[0][3].ToString();
            apartado.Descripcion = datos_usuarios.Tables[0].Rows[0][4].ToString();

            this.conn.Close();

            return apartado;

        }

        public string enviar_correo(correo Correo)
        {
            // Definir características del cuerpo

            MailMessage email = new MailMessage();
            email.To.Add(new MailAddress(Correo.Email));
            email.From = new MailAddress("noreply@ufidelitas.ac.cr");
            email.Subject = "Reserva de equipo";

            string htmlBody = "";
            htmlBody += "<div><table>";
            htmlBody += "<tr><td>ID :</td><td>" +  Correo.Identificador + "</td></tr>";
            htmlBody += "<tr><td>Nombre :</td><td>" + Correo.Nombre + "</td></tr>";
            htmlBody += "<tr><td>Primer Apellido :</td><td>" + Correo.P_apellido + "</td></tr>";
            htmlBody += "<tr><td>Segundo Apellido :</td><td>" + Correo.S_apellido + "</td></tr>";
            htmlBody += "<tr><td>Fecha :</td><td>" + Correo.Fecha + "</td></tr>";
            htmlBody += "<tr><td>Turno :</td><td>" + Correo.Turno + "</td></tr>";

            foreach(string equipo in Correo.Tipo){

                if(equipo != ""){
                    htmlBody += "<tr><td>Equipo Apartado :</td><td>" + equipo + "</td></tr>";
                }

            }

            htmlBody += "</div></table>";
            htmlBody += "<div>Mensaje Personalizado</div>";

            email.Body = htmlBody;

            email.IsBodyHtml = true;
            email.Priority = MailPriority.Normal;   

            // Definir objeto smtp

            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.office365.com";
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = new NetworkCredential("noreply@ufidelitas.ac.cr", "Activo.17");

            string message = null;

            try
            {
                smtp.Send(email);
                email.Dispose();
                message = "OK";
            }
            catch (Exception ex)
            {
                message = "Error enviando correo electrónico: " + ex.Message;
            }

            return message;
        }

        public correo ver_apartado_fecha_turno_id(string identificador,DateTime fecha, string turno)
        {
            string query = "EXEC ver_apartado_fecha_turno_id [@IDENTIFICADOR],[@FECHA],[@TURNO]";

            OleDbCommand cmd = new OleDbCommand(query, this.conn);

            OleDbDataReader dr;

            OleDbParameter param_identificador = new OleDbParameter();
            param_identificador.DbType = DbType.String;
            param_identificador.ParameterName = "IDENTIFICADOR";
            param_identificador.Value = identificador;

            OleDbParameter param_fecha = new OleDbParameter();
            param_fecha.DbType = DbType.Date;
            param_fecha.ParameterName = "FECHA";
            param_fecha.Value = fecha;

            OleDbParameter param_turno = new OleDbParameter();
            param_turno.DbType = DbType.String;
            param_turno.ParameterName = "TURNO";
            param_turno.Value = turno;

            cmd.Parameters.Add(param_identificador);
            cmd.Parameters.Add(param_fecha);
            cmd.Parameters.Add(param_turno);

            DataTable tabla_apartados = new DataTable();

            tabla_apartados.Columns.Add("identificador");
            tabla_apartados.Columns.Add("nombre");
            tabla_apartados.Columns.Add("p_apellido");
            tabla_apartados.Columns.Add("s_apellido");
            tabla_apartados.Columns.Add("correo");
            tabla_apartados.Columns.Add("fecha");
            tabla_apartados.Columns.Add("turno");
            tabla_apartados.Columns.Add("tipo");


            this.abrir_conexion();

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                DataRow fila = tabla_apartados.NewRow();

                fila["identificador"] = dr["identificador"];
                fila["nombre"] = dr["nombre"];
                fila["p_apellido"] = dr["p_apellido"];
                fila["s_apellido"] = dr["s_apellido"];
                fila["correo"] = dr["correo"];
                fila["fecha"] = dr["fecha"];
                fila["turno"] = dr["turno"];
                fila["tipo"] = dr["tipo"];

                tabla_apartados.Rows.Add(fila);

            }

            this.cerrar_conexion();

            correo Correo = new correo();

            Correo.Identificador = tabla_apartados.Rows[0][0].ToString();
            Correo.Nombre = tabla_apartados.Rows[0][1].ToString();
            Correo.P_apellido = tabla_apartados.Rows[0][2].ToString();
            Correo.S_apellido = tabla_apartados.Rows[0][3].ToString();
            Correo.Email = tabla_apartados.Rows[0][4].ToString();
            Correo.Fecha = DateTime.Parse(tabla_apartados.Rows[0][5].ToString());
            Correo.Turno = tabla_apartados.Rows[0][6].ToString();
            
            for (int contador = 0; contador < tabla_apartados.Rows.Count; contador ++ )
            {

                    Correo.Tipo[contador] = tabla_apartados.Rows[contador][7].ToString();

                    contador++;

            }

            return Correo;

        }
    }
}
