﻿namespace app
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtPApellido = new System.Windows.Forms.TextBox();
            this.txtSApellido = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnExportarExcel = new System.Windows.Forms.Button();
            this.btnDiponiblidadEquipo = new System.Windows.Forms.Button();
            this.ckEquiposUnicos = new System.Windows.Forms.CheckBox();
            this.btnIngresarApartado = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.cbTurno = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvEquipoParaReserva = new System.Windows.Forms.DataGridView();
            this.dgDisponibilidad = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEquipoParaReserva)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgDisponibilidad)).BeginInit();
            this.SuspendLayout();
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(123, 19);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(152, 20);
            this.txtID.TabIndex = 0;
            this.txtID.TextChanged += new System.EventHandler(this.txtID_TextChanged);
            this.txtID.Leave += new System.EventHandler(this.txtID_Leave);
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(123, 45);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.ReadOnly = true;
            this.txtNombre.Size = new System.Drawing.Size(152, 20);
            this.txtNombre.TabIndex = 1;
            // 
            // txtPApellido
            // 
            this.txtPApellido.Location = new System.Drawing.Point(123, 71);
            this.txtPApellido.Name = "txtPApellido";
            this.txtPApellido.ReadOnly = true;
            this.txtPApellido.Size = new System.Drawing.Size(152, 20);
            this.txtPApellido.TabIndex = 2;
            // 
            // txtSApellido
            // 
            this.txtSApellido.Location = new System.Drawing.Point(123, 97);
            this.txtSApellido.Name = "txtSApellido";
            this.txtSApellido.ReadOnly = true;
            this.txtSApellido.Size = new System.Drawing.Size(152, 20);
            this.txtSApellido.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.dtpFecha);
            this.groupBox1.Controls.Add(this.cbTurno);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtID);
            this.groupBox1.Controls.Add(this.txtSApellido);
            this.groupBox1.Controls.Add(this.txtNombre);
            this.groupBox1.Controls.Add(this.txtPApellido);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(604, 207);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnExportarExcel);
            this.groupBox2.Controls.Add(this.btnDiponiblidadEquipo);
            this.groupBox2.Controls.Add(this.ckEquiposUnicos);
            this.groupBox2.Controls.Add(this.btnIngresarApartado);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Location = new System.Drawing.Point(294, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(282, 111);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Panel de Acción";
            // 
            // btnExportarExcel
            // 
            this.btnExportarExcel.Location = new System.Drawing.Point(133, 49);
            this.btnExportarExcel.Name = "btnExportarExcel";
            this.btnExportarExcel.Size = new System.Drawing.Size(121, 23);
            this.btnExportarExcel.TabIndex = 21;
            this.btnExportarExcel.Text = "Exportar Excel";
            this.btnExportarExcel.UseVisualStyleBackColor = true;
            this.btnExportarExcel.Visible = false;
            this.btnExportarExcel.Click += new System.EventHandler(this.button2_Click_3);
            // 
            // btnDiponiblidadEquipo
            // 
            this.btnDiponiblidadEquipo.Location = new System.Drawing.Point(6, 49);
            this.btnDiponiblidadEquipo.Name = "btnDiponiblidadEquipo";
            this.btnDiponiblidadEquipo.Size = new System.Drawing.Size(121, 23);
            this.btnDiponiblidadEquipo.TabIndex = 7;
            this.btnDiponiblidadEquipo.Text = "Ver Disponiblidad";
            this.btnDiponiblidadEquipo.UseVisualStyleBackColor = true;
            this.btnDiponiblidadEquipo.Click += new System.EventHandler(this.button2_Click);
            // 
            // ckEquiposUnicos
            // 
            this.ckEquiposUnicos.AutoSize = true;
            this.ckEquiposUnicos.Location = new System.Drawing.Point(133, 84);
            this.ckEquiposUnicos.Name = "ckEquiposUnicos";
            this.ckEquiposUnicos.Size = new System.Drawing.Size(138, 17);
            this.ckEquiposUnicos.TabIndex = 18;
            this.ckEquiposUnicos.Text = "Ver solo equipos únicos";
            this.ckEquiposUnicos.UseVisualStyleBackColor = true;
            this.ckEquiposUnicos.Visible = false;
            // 
            // btnIngresarApartado
            // 
            this.btnIngresarApartado.Location = new System.Drawing.Point(6, 19);
            this.btnIngresarApartado.Name = "btnIngresarApartado";
            this.btnIngresarApartado.Size = new System.Drawing.Size(121, 23);
            this.btnIngresarApartado.TabIndex = 19;
            this.btnIngresarApartado.Text = "Realizar Apartado";
            this.btnIngresarApartado.UseVisualStyleBackColor = true;
            this.btnIngresarApartado.Click += new System.EventHandler(this.btnIngresarApartado_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 78);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Ver Apartado";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dtpFecha
            // 
            this.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha.Location = new System.Drawing.Point(123, 124);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(121, 20);
            this.dtpFecha.TabIndex = 17;
            this.dtpFecha.ValueChanged += new System.EventHandler(this.dtpFecha_ValueChanged);
            // 
            // cbTurno
            // 
            this.cbTurno.FormattingEnabled = true;
            this.cbTurno.Location = new System.Drawing.Point(123, 148);
            this.cbTurno.Name = "cbTurno";
            this.cbTurno.Size = new System.Drawing.Size(121, 21);
            this.cbTurno.TabIndex = 16;
            this.cbTurno.SelectedIndexChanged += new System.EventHandler(this.cbTurno_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Turno";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 127);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Fecha";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Primer Apellido";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Segundo Apellido";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Número ID";
            // 
            // dgvEquipoParaReserva
            // 
            this.dgvEquipoParaReserva.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEquipoParaReserva.Location = new System.Drawing.Point(622, 12);
            this.dgvEquipoParaReserva.Name = "dgvEquipoParaReserva";
            this.dgvEquipoParaReserva.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dgvEquipoParaReserva.Size = new System.Drawing.Size(293, 207);
            this.dgvEquipoParaReserva.TabIndex = 8;
            this.dgvEquipoParaReserva.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEquipoParaReserva_CellContentClick);
            // 
            // dgDisponibilidad
            // 
            this.dgDisponibilidad.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDisponibilidad.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgDisponibilidad.Location = new System.Drawing.Point(12, 225);
            this.dgDisponibilidad.Name = "dgDisponibilidad";
            this.dgDisponibilidad.Size = new System.Drawing.Size(903, 250);
            this.dgDisponibilidad.TabIndex = 5;
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(927, 487);
            this.Controls.Add(this.dgvEquipoParaReserva);
            this.Controls.Add(this.dgDisponibilidad);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "main";
            this.Text = "main";
            this.Load += new System.EventHandler(this.main_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEquipoParaReserva)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgDisponibilidad)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtPApellido;
        private System.Windows.Forms.TextBox txtSApellido;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.ComboBox cbTurno;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnDiponiblidadEquipo;
        private System.Windows.Forms.CheckBox ckEquiposUnicos;
        private System.Windows.Forms.DataGridView dgvEquipoParaReserva;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnIngresarApartado;
        private System.Windows.Forms.DataGridView dgDisponibilidad;
        private System.Windows.Forms.Button btnExportarExcel;
    }
}