﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using app.Clases;


namespace app
{
    public partial class main : Form
    {
        public static int init_1;
        public static int init_2;
        public static int cantidad;

        public main()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            apartado da = new apartado();

            DateTime fecha = this.dtpFecha.Value;

            if(init_2 == 1){

                this.dgDisponibilidad.DataSource = da.obtener_apartados_fecha_turno(fecha, this.cbTurno.Text);

                item.table_items = da.obtener_apartados_fecha_turno(fecha, this.cbTurno.Text);

                this.dgDisponibilidad.Columns[0].Width = 70;
                this.dgDisponibilidad.Columns[1].Width = 80;
                this.dgDisponibilidad.Columns[2].Width = 110;
                this.dgDisponibilidad.Columns[3].Width = 110;
                this.dgDisponibilidad.Columns[4].Width = 70;
                this.dgDisponibilidad.Columns[5].Width = 60;
                this.dgDisponibilidad.Columns[6].Width = 40;
                this.dgDisponibilidad.Columns[7].Width = 110;
                this.dgDisponibilidad.Columns[8].Width = 210;
            
            }else{

                this.dgDisponibilidad.DataSource = da.obtener_apartados_fecha_turno(fecha, this.cbTurno.Text);

                item.table_items = da.obtener_apartados_fecha_turno(fecha, this.cbTurno.Text);
            
            }

            init_2 += 1;

         

        }

        private void button2_Click(object sender, EventArgs e)
        {

                apartado da = new apartado();

                DateTime fecha = this.dtpFecha.Value;

                string turno = this.cbTurno.SelectedText;

                this.dgvEquipoParaReserva.DataSource = da.obtener_equipo_disponible_apartado(fecha, this.cbTurno.Text);

                // HERE YOU FORMAT THE BUSY ITEMS DATAGRIDVIEW
                
                if (init_1 == 1){

                    this.dgvEquipoParaReserva.Columns[0].Width = 40;
                    this.dgvEquipoParaReserva.Columns[1].Width = 160;
       
                    this.dgvEquipoParaReserva.Columns[0].ReadOnly = true;
                    this.dgvEquipoParaReserva.Columns[1].ReadOnly = true;

                }

                if (init_1 == 1)
                {

                    DataGridViewCheckBoxColumn selectItem = new DataGridViewCheckBoxColumn();
                    selectItem.Name = "seleccion";
                    selectItem.HeaderText = "Selección de Articulos";
                    selectItem.Width = 50;
                    selectItem.ReadOnly = false;
                    this.dgvEquipoParaReserva.Columns.Add(selectItem);

                    this.dgvEquipoParaReserva.Columns[2].Width = 50;
                    this.dgvEquipoParaReserva.Columns[2].ReadOnly = false;
                }

                init_1 += 1;
            
        }

        private void main_Load(object sender, EventArgs e)
        {

            string[] lineas = System.IO.File.ReadAllLines(@"C:\Program Files (x86)\app\conexion.txt");

            foreach (string linea in lineas)
            {
                item.dbcon = linea;
            }

            this.cbTurno.DisplayMember= "name";
            this.cbTurno.ValueMember = "value";

            this.cbTurno.Items.Add(new turno("MAÑANA", "MAÑANA"));
            this.cbTurno.Items.Add(new turno("INTERMEDIO", "INTERMEDIO"));
            this.cbTurno.Items.Add(new turno("TARDE", "TARDE"));
            this.cbTurno.Items.Add(new turno("NOCHE", "NOCHE"));

            this.cbTurno.SelectedIndex = 3;

            init_1 = 1;
            init_2 = 1;

            equipo Equipo = new equipo();
            cantidad = Equipo.obtener_cantidad_equipo();

            item.establecer_items(cantidad);

            this.btnDiponiblidadEquipo.PerformClick();
            this.button1.PerformClick();

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtID_Leave(object sender, EventArgs e)
        {

            if (txtID.Text.Length > 6)
            {
                datos Datos = new datos();
                usuario Usuario = new usuario();

                Usuario = Datos.obtener_usuario_id(this.txtID.Text);

                if (Usuario != null)
                {
                    this.txtNombre.Text = Usuario.Nombre;
                    this.txtPApellido.Text = Usuario.P_apellido;
                    this.txtSApellido.Text = Usuario.S_apellido;
                }
                else
                {
                    MessageBox.Show("No se encontro ningún usuario con este identificador");
                }

                Usuario = null;
                Datos = null;

            }

            
         
        }

        private void button2_Click_1(object sender, EventArgs e)
        {


        }

        private void btnIngresarApartado_Click(object sender, EventArgs e)
        {

            if (txtID.Text != "" && txtNombre.Text != "" && txtPApellido.Text != "" && txtSApellido.Text != "")
            {
                apartado Apartado = new apartado();

                item.table_items = Apartado.obtener_equipo_disponible_apartado(this.dtpFecha.Value, this.cbTurno.Text);

                DateTime fecha = this.dtpFecha.Value;
                apartado a = new apartado(this.txtID.Text, fecha, this.cbTurno.Text, "");
                apartado_equipo Equipo_Apartado = new apartado_equipo();

                int contador_equipo = 0;

                for (int contador = 0; contador < item.canitdad(); contador++)
                {
                    if (item.items[contador])
                    {
                        Equipo_Apartado.Codigo[contador_equipo] = item.table_items.Rows[contador][0].ToString();
                        contador_equipo++;
                    }
                }

                int resultado = a.ingresar_apartado(Equipo_Apartado);

                if (resultado == -1)
                {

                    MessageBox.Show("Hubo un problema al ingresar el registro");
                    
                }


                if (resultado != 0)
                {
                    foreach (DataGridViewRow row in this.dgvEquipoParaReserva.Rows)
                    {
                        row.Cells[2].Value = false;
                    }

                    for (int contador = 0; contador < item.canitdad(); contador++)
                    {
                        item.items[contador] = false;
                    }

                }

                datos Datos = new datos();
                correo Correo = Datos.ver_apartado_fecha_turno_id(this.txtID.Text, this.dtpFecha.Value, this.cbTurno.Text);

                string mensaje = Datos.enviar_correo(Correo);

                // Me avisa si hubo un error al envíar un correo

                if (mensaje != "OK") 
                {
                    MessageBox.Show(mensaje);
                }

                this.button1.PerformClick();
                this.btnDiponiblidadEquipo.PerformClick();

                this.txtID.Text = "";
                this.txtNombre.Text = "";
                this.txtPApellido.Text = "";
                this.txtSApellido.Text = "";
                this.cbTurno.SelectedItem = 3;

                MessageBox.Show("Registro Ingresado Correctamente");


            }
            else 
            {
                MessageBox.Show("Faltan argumentos para poder seguir con el apartado");
            }

        }

        private void dgvEquipoParaReserva_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            item.values(e.RowIndex);

        }

        private void dtpFecha_ValueChanged(object sender, EventArgs e)
        {
            this.btnDiponiblidadEquipo.PerformClick();
            this.button1.PerformClick();
        }

        private void cbTurno_SelectedIndexChanged(object sender, EventArgs e)
        {

            this.btnDiponiblidadEquipo.PerformClick();
            this.button1.PerformClick();
        }

        private void button2_Click_2(object sender, EventArgs e)
        {

            

        }

        private void button2_Click_3(object sender, EventArgs e)
        {
            foreach (DataGridViewRow Rows in this.dgDisponibilidad.Rows)
            {

                foreach (DataGridViewCell cell in Rows.Cells)
                {

                    if (cell.Value != null)
                    {
                        MessageBox.Show(cell.Value.ToString());
                    }

                }
            }
        }
    }
}
