﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace app.Clases
{
    class apartado : conexion
    {

        public apartado() { 
        
        }

        public apartado(string identificador,DateTime fecha, string turno,string descripcion)
        {

            this.identificador = identificador;
            this.fecha = fecha;
            this.turno = turno;
            this.descripcion = descripcion;

        }

        private int id_apartado;  // the name field
        public int Id_apartado    // the identificador property
        {
            get
            {
                return id_apartado;
            }
            set
            {
                id_apartado = value;
            }
        }


        private string identificador;  // the name field
        public string Identificador    // the identificador property
        {
            get
            {
                return identificador;
            }
            set
            {
                identificador = value;
            }
        }

        private DateTime fecha;  // the name field
        public DateTime Fecha    // the identificador property
        {
            get
            {
                return fecha;
            }
            set
            {
                fecha = value;
            }
        }

        private string turno;  // the name field
        public string Turno    // the identificador property
        {
            get
            {
                return turno;
            }
            set
            {
                turno = value;
            }
        }

        private string descripcion;  // the name field
        public string Descripcion    // the identificador property
        {
            get
            {
                return descripcion;
            }
            set
            {
                descripcion = value;
            }
        }

        /* Crear navegación para equipos_apartados
          
        private apartado_equipo equipo_apartado;
        public apartado_equipo Equipo_apartado
        {
            get
            {

                return Equipo_apartado;
            }
            set
            {
                equipo_apartado = value;
            }
        }*/

        public int ingresar_apartado(apartado_equipo Equipo_Apartado) //
        {

            string sql = "";
            int resultado = 0;
            sql = "INSERT INTO apartado (identificador,fecha,turno) VALUES (@identificador,@fecha,@turno)";
            OleDbCommand cmd = new OleDbCommand(sql, this.conn);
            //apartado_equipo equipo_apartado = new apartado_equipo();

            OleDbParameter identificador = new OleDbParameter();
            identificador.ParameterName = "identificador";
            identificador.OleDbType = OleDbType.VarChar;
            identificador.Value = this.identificador;

            OleDbParameter fecha = new OleDbParameter();
            fecha.ParameterName = "fecha";
            fecha.OleDbType = OleDbType.DBDate;
            fecha.Value = this.fecha;

            OleDbParameter turno = new OleDbParameter();
            turno.ParameterName = "turno";
            turno.OleDbType = OleDbType.VarChar;
            turno.Value = this.turno;

            cmd.Parameters.Add(identificador);
            cmd.Parameters.Add(fecha);
            cmd.Parameters.Add(turno);

            this.abrir_conexion();

            try
            {
                resultado = cmd.ExecuteNonQuery();
            }
            catch(Exception e)
            {
                resultado = -1;
            }
            finally
            {
                this.cerrar_conexion();
            }

            DataSet identity = this.datos("EXEC ident '" + this.identificador + "'");
            int identityKey = (int)identity.Tables[0].Rows[0][0];

            this.cerrar_conexion();

            //equipo_apartado.Id_apartado = identityKey;

            Equipo_Apartado.Id_apartado = identityKey;
            Equipo_Apartado.ingresar_apartado_equipo();

            return identityKey;

        }

        public DataSet obtener_apartados_fecha(DateTime fecha)
        {

            string query1;

            query1 = "EXEC ver_apartado_fecha # " + fecha.ToShortDateString() + "#";

            System.Data.DataSet apartado = new System.Data.DataSet();
            apartado = this.datos(query1);
            
            return apartado;

        }

        public DataTable obtener_apartados_fecha_turno(DateTime fecha,string turno)
        {
            string query = "EXEC ver_apartado_fecha_turno [@FECHA], [@TURNO]";

            OleDbCommand cmd = new OleDbCommand(query, this.conn);

            OleDbDataReader dr;

            OleDbParameter param_fecha = new OleDbParameter();
            param_fecha.DbType = DbType.Date;
            param_fecha.ParameterName = "FECHA";
            param_fecha.Value = fecha;

            OleDbParameter param_turno = new OleDbParameter();
            param_turno.DbType = DbType.String;
            param_turno.ParameterName = "TURNO";
            param_turno.Value = turno;

            cmd.Parameters.Add(param_fecha);
            cmd.Parameters.Add(param_turno);

            this.abrir_conexion();

            dr = cmd.ExecuteReader();
            DataTable tabla_apartados = new DataTable();
            tabla_apartados.Columns.Add("identificador");
            tabla_apartados.Columns.Add("nombre");
            tabla_apartados.Columns.Add("p_apellido");
            tabla_apartados.Columns.Add("s_apellido");
            tabla_apartados.Columns.Add("fecha");
            tabla_apartados.Columns.Add("turno");
            tabla_apartados.Columns.Add("codigo");
            tabla_apartados.Columns.Add("tipo");
            tabla_apartados.Columns.Add("descripcion");

            while (dr.Read())
            {

                DataRow fila = tabla_apartados.NewRow();

                fila["identificador"] = dr["identificador"];
                fila["nombre"] = dr["nombre"];
                fila["p_apellido"] = dr["p_apellido"];
                fila["s_apellido"] = dr["s_apellido"];
                fila["fecha"] = dr["fecha"];
                fila["turno"] = dr["turno"];
                fila["codigo"] = dr["codigo"];
                fila["tipo"] = dr["tipo"];
                fila["descripcion"] = dr["descripcion"];

                tabla_apartados.Rows.Add(fila);


            }

            this.cerrar_conexion();

            return tabla_apartados;
            

        }

        public System.Data.DataSet obtener_todo_apartado()
        {

            string query1;

            query1 = "EXEC ver_apartado";

            System.Data.DataSet apartado = new System.Data.DataSet();
            apartado = this.datos(query1);

            return apartado;

        }

        public System.Data.DataTable obtener_equipo_disponible_apartado(DateTime fecha,string turno)
        {

            string query = "EXEC ver_equipo_disponible_turno_fecha [@FECHA], [@TURNO]";

            OleDbCommand cmd = new OleDbCommand(query, this.conn);

            OleDbDataReader dr;

            OleDbParameter param_fecha = new OleDbParameter();
            param_fecha.DbType = DbType.Date;
            param_fecha.ParameterName = "FECHA";
            param_fecha.Value = fecha;

            OleDbParameter param_turno = new OleDbParameter();
            param_turno.DbType = DbType.String;
            param_turno.ParameterName = "TURNO";
            param_turno.Value = turno;

            cmd.Parameters.Add(param_fecha);
            cmd.Parameters.Add(param_turno);

            this.abrir_conexion();

            dr = cmd.ExecuteReader();
            DataTable equipo_disponible = new DataTable();
            equipo_disponible.Columns.Add("codigo");
            equipo_disponible.Columns.Add("tipo");

            while (dr.Read())
            {

                DataRow fila = equipo_disponible.NewRow();

                fila["codigo"] = dr["codigo"];
                fila["tipo"] = dr["tipo"];

                equipo_disponible.Rows.Add(fila);


            }

            this.cerrar_conexion();

            return equipo_disponible;

        }

        

    }
}
