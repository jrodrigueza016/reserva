﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace app.Clases
{
    class correo
    {

        public correo(){

            this.tipo = new string[8] { "", "", "", "", "", "", "", "" };
        }

        public correo(string identificador,string nombre, string p_apellido,string s_apellido,string email, DateTime fecha, string turno,string[] tipo)
        {

            this.identificador = identificador;
            this.nombre = nombre;
            this.p_apellido = p_apellido;
            this.s_apellido = s_apellido;
            this.email = email;
            this.fecha = fecha;
            this.turno = turno;
            this.tipo = new string[8] { "", "", "", "", "", "", "", "" };

        }



        private string identificador;  // the name field
        public string Identificador    // the identificador property
        {
            get
            {
                return identificador;
            }
            set
            {
                identificador = value;
            }
        }


        private string nombre;  // the name field
        public string Nombre    // the identificador property
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }

        private string p_apellido;  // the name field
        public string P_apellido    // the identificador property
        {
            get
            {
                return p_apellido;
            }
            set
            {
                p_apellido = value;
            }
        }

        private string s_apellido;  // the name field
        public string S_apellido    // the identificador property
        {
            get
            {
                return s_apellido;
            }
            set
            {
                s_apellido = value;
            }
        }

        private string email;  // the name field
        public string Email    // the identificador property
        {
            get
            {
                return email;
            }
            set
            {
                email = value;
            }
        }

        private DateTime fecha;  // the name field
        public DateTime Fecha    // the identificador property
        {
            get
            {
                return fecha;
            }
            set
            {
                fecha = value;
            }
        }

        private string turno;  // the name field
        public string Turno    // the identificador property
        {
            get
            {
                return turno;
            }
            set
            {
                turno = value;
            }
        }

        private string[] tipo;  // the name field
        public string[] Tipo    // the identificador property
        {
            get
            {
                return tipo;
            }
            set
            {
                tipo = value;
            }
        }

    }
}
