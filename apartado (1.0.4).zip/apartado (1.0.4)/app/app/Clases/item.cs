﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// this is a class created to save some data to solve some issues with gridview 

namespace app.Clases
{
    public static class item
    {

        public static string dbcon;

        public static bool[] items;

        public static System.Data.DataTable table_items;

        public static void establecer_items(int cantidad) { 
        
            items = new bool[cantidad];
        
        }

        public static void values(int index){

            if (items[index])
            {
                items[index] = false;
                return;
            }

            if (!items[index])
            {
                items[index] = true;
                return;
            }
        }

        public static int canitdad() 
        {
            return items.Count();
        }
        
    }
}
