﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace app.Clases
{
    class equipo : conexion
    {

        public equipo() { 
        
        }

        public equipo(string codigo,string tipo,string marca,string descripcion)
        {
            this.codigo = codigo;
            this.tipo = tipo;
            this.marca = marca;
            this.descripcion = descripcion;
        }

        private string codigo;  // the name field
        public string Codigo    // the identificador property
        {
            get
            {
                return codigo;
            }
            set
            {
                codigo = value;
            }
        }


        private string tipo;  // the name field
        public string Tipo    // the identificador property
        {
            get
            {
                return tipo;
            }
            set
            {
                tipo = value;
            }
        }

        private string marca;  // the name field
        public string Marca    // the identificador property
        {
            get
            {
                return marca;
            }
            set
            {
                marca = value;
            }
        }

        private string descripcion;  // the name field
        public string Descripcion    // the identificador property
        {
            get
            {
                return descripcion;
            }
            set
            {
                descripcion = value;
            }
        }


        public int ingresar_equipo()
        {

            string sql = "";
            int resultado = 0;
            sql = "INSERT INTO equipo (codigo,tipo,marca,descripcion) VALUES (@codigo,@tipo,@marca,@descripcion)";
            OleDbCommand cmd = new OleDbCommand(sql, this.conn);

            OleDbParameter codigo = new OleDbParameter();
            codigo.ParameterName = "codigo";
            codigo.OleDbType = OleDbType.VarChar;
            codigo.Value = this.codigo;

            OleDbParameter tipo = new OleDbParameter();
            tipo.ParameterName = "tipo";
            tipo.OleDbType = OleDbType.VarChar;
            tipo.Value = this.tipo;

            OleDbParameter marca = new OleDbParameter();
            marca.ParameterName = "marca";
            marca.OleDbType = OleDbType.VarChar;
            marca.Value = this.marca;

            OleDbParameter descripcion = new OleDbParameter();
            descripcion.ParameterName = "descripcion";
            descripcion.OleDbType = OleDbType.VarChar;
            descripcion.Value = this.descripcion;

            cmd.Parameters.Add(codigo);
            cmd.Parameters.Add(tipo);
            cmd.Parameters.Add(marca);
            cmd.Parameters.Add(descripcion);


            this.abrir_conexion();
            resultado = cmd.ExecuteNonQuery();
            this.cerrar_conexion();

            return resultado;

        }

        public int obtener_cantidad_equipo() 
        {
            int cantidad_equipo = 0;
            string query = "SELECT COUNT(equipo.codigo) AS cantidad FROM equipo;";
            DataSet datos = this.datos(query);

            cantidad_equipo = (int)datos.Tables["tabla_generica"].Rows[0][0];

            this.cerrar_conexion();

            return cantidad_equipo;
        }
       

    }
}
