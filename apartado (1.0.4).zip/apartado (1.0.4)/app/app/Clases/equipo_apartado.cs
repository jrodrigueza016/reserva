﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;

namespace app.Clases
{
    class apartado_equipo : conexion
    {
        public apartado_equipo()
        {
            this.codigo = new string[8] { "", "", "", "", "", "", "", "" };
        }

        public apartado_equipo(int id_apartado,string[] codigo) {

            this.id_apartado = id_apartado;
            this.codigo = codigo;
            this.codigo = new string[8] { "", "", "", "", "", "", "", ""};

        }

        private int id;  // the name field
        public int Id  // the identificador property
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }

        private int id_apartado;  // the name field
        public int Id_apartado    // the identificador property
        {
            get
            {
                return id_apartado;
            }
            set
            {
                id_apartado = value;
            }
        }

        private string[] codigo;  // the name field
        public string[] Codigo    // the identificador property
        {
            get
            {
                return codigo;
            }
            set
            {
                codigo = value;
            }
        }

        public int ingresar_apartado_equipo()
        {

            string sql = "";
            int resultado = 0;
            
            OleDbCommand cmd ; //= new OleDbCommand(sql, this.conn);
            this.abrir_conexion();

            foreach(var cod in this.codigo){

                if (cod != "")
                {
                    sql = "INSERT INTO [apartado-equipo] (id_apartado,codigo) VALUES (" + this.id_apartado + ",'" + cod + "')";
                    cmd = new OleDbCommand(sql, this.conn);
                    resultado = cmd.ExecuteNonQuery();
                }
                
            }

            this.cerrar_conexion();

            return resultado;

        }


    }
}
